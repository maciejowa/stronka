document.getElementById('acceptBtn').addEventListener('click', function() {
    alert('Dziękuję za potwierdzenie! JESTES NAJPIEKNIEJSZA OSOBA NA SWIECIE!');
  });